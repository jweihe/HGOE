README for dataset MMP


=== Usage ===

This folder contains the following comma separated text files 
(replace DS by the name of the dataset):

n = total number of nodes
m = total number of edges
N = number of graphs

(1) 	DS_A.txt (m lines) 
	sparse (block diagonal) adjacency matrix for all graphs,
	each line corresponds to (row, col) resp. (node_id, node_id)

(2) 	DS_graph_indicator.txt (n lines)
	column vector of graph identifiers for all nodes of all graphs,
	the value in the i-th line is the graph_id of the node with node_id i

(3) 	DS_graph_labels.txt (N lines) 
	class labels for all graphs in the dataset,
	the value in the i-th line is the class label of the graph with graph_id i

(4) 	DS_node_labels.txt (n lines)
	column vector of node labels,
	the value in the i-th line corresponds to the node with node_id i

There are OPTIONAL files if the respective information is available:

(5) 	DS_edge_labels.txt (m lines; same size as DS_A_sparse.txt)
	labels for the edges in DS_A_sparse.txt 

(6) 	DS_edge_attributes.txt (m lines; same size as DS_A.txt)
	attributes for the edges in DS_A.txt 

(7) 	DS_node_attributes.txt (n lines) 
	matrix of node attributes,
	the comma seperated values in the i-th line is the attribute vector of the node with node_id i

(8) 	DS_graph_attributes.txt (N lines) 
	regression values for all graphs in the dataset,
	the value in the i-th line is the attribute of the graph with graph_id i


=== Node Label Conversion === 

Node labels were converted to integer values using this map:

Component 0:
	0	C
	1	N
	2	F
	3	O
	4	Cl
	5	P
	6	Br
	7	S
	8	I
	9	B
	10	Sn
	11	Na
	12	Zn
	13	Cd
	14	V
	15	As
	16	Au
	17	Li
	18	Hg
	19	Se
	20	Co
	21	Ag
	22	Si
	23	K
	24	Sb
	25	Pt
	26	Ca
	27	Cu
	28	Al
	29	Ba
	30	Fe
	31	Ti
	32	Tl
	33	Sr
	34	Bi
	35	In
	36	Ni
	37	Cr
	38	Mg
	39	Nd
	40	Pd
	41	Mn
	42	Zr
	43	Pb
	44	Yb
	45	Mo
	46	Ge



Edge labels were converted to integer values using this map:

Component 0:
	0	single
	1	aromatic
	2	double
	3	triple


=== References ===

Tox21 Data Challenge 2014, https://tripod.nih.gov/tox21/challenge/data.jsp
