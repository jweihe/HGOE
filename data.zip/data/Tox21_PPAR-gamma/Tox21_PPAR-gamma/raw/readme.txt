README for dataset PPAR-gamma


=== Usage ===

This folder contains the following comma separated text files 
(replace DS by the name of the dataset):

n = total number of nodes
m = total number of edges
N = number of graphs

(1) 	DS_A.txt (m lines) 
	sparse (block diagonal) adjacency matrix for all graphs,
	each line corresponds to (row, col) resp. (node_id, node_id)

(2) 	DS_graph_indicator.txt (n lines)
	column vector of graph identifiers for all nodes of all graphs,
	the value in the i-th line is the graph_id of the node with node_id i

(3) 	DS_graph_labels.txt (N lines) 
	class labels for all graphs in the dataset,
	the value in the i-th line is the class label of the graph with graph_id i

(4) 	DS_node_labels.txt (n lines)
	column vector of node labels,
	the value in the i-th line corresponds to the node with node_id i

There are OPTIONAL files if the respective information is available:

(5) 	DS_edge_labels.txt (m lines; same size as DS_A_sparse.txt)
	labels for the edges in DS_A_sparse.txt 

(6) 	DS_edge_attributes.txt (m lines; same size as DS_A.txt)
	attributes for the edges in DS_A.txt 

(7) 	DS_node_attributes.txt (n lines) 
	matrix of node attributes,
	the comma seperated values in the i-th line is the attribute vector of the node with node_id i

(8) 	DS_graph_attributes.txt (N lines) 
	regression values for all graphs in the dataset,
	the value in the i-th line is the attribute of the graph with graph_id i


=== Node Label Conversion === 

Node labels were converted to integer values using this map:

Component 0:
	0	N
	1	C
	2	O
	3	S
	4	I
	5	Cl
	6	Hg
	7	F
	8	Sn
	9	Br
	10	Zn
	11	P
	12	Na
	13	Ca
	14	Li
	15	Cu
	16	Se
	17	Ag
	18	Si
	19	B
	20	K
	21	Pt
	22	Co
	23	Al
	24	As
	25	Bi
	26	Ba
	27	Fe
	28	Au
	29	Ti
	30	Sr
	31	In
	32	Ni
	33	Cr
	34	Sb
	35	Be
	36	Mg
	37	Nd
	38	Pd
	39	Mn
	40	Zr
	41	Pb
	42	Yb
	43	Mo
	44	Cd
	45	Ge



Edge labels were converted to integer values using this map:

Component 0:
	0	single
	1	double
	2	aromatic
	3	triple


=== References ===

Tox21 Data Challenge 2014, https://tripod.nih.gov/tox21/challenge/data.jsp
